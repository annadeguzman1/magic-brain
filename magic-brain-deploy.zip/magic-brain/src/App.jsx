import { useState, useEffect, useCallback, useRef, useMemo } from "react";

const VENUE_TYPES = ["Close-up", "Parlor", "Corporate", "Trade Show", "Private Party", "Virtual", "Stage", "Wedding", "Festival"];
const CATEGORIES = ["Card Magic", "Mentalism", "Coin", "Parlor", "Stage", "Prop", "Impromptu", "Other"];
const DIFFICULTY = ["Self-Working", "Easy", "Intermediate", "Advanced", "Expert"];
const REACTION_LABELS = ["", "Flat", "Polite", "Good", "Strong", "Showstopper"];
const EXPENSE_CATS = ["Travel", "Flights", "Hotel", "Uber/Lyft", "Props", "Meals", "Parking", "Shipping", "Wardrobe", "Marketing", "Tips", "Other"];
const PIPELINE = [
  { key: "inquiry", label: "Inquiry", color: "#6b8afd", icon: "📩" },
  { key: "negotiating", label: "Negotiating", color: "#ffa94d", icon: "🤝" },
  { key: "booked", label: "Booked", color: "#c9a227", icon: "✅" },
  { key: "completed", label: "Completed", color: "#22c955", icon: "🎭" },
  { key: "paid", label: "Paid", color: "#22c955", icon: "💰" },
  { key: "cancelled", label: "Cancelled", color: "#ff6b6b", icon: "✕" },
];
const FOLLOWUP_TYPES = ["Send Contract", "Send Invoice", "Follow Up", "Confirm Details", "Send Thank You", "Request Review", "Custom"];

const STORAGE_KEY = "magic-brain-db-v3";
function loadData() { try { const r = localStorage.getItem(STORAGE_KEY); if (r) return JSON.parse(r); } catch {} return null; }
function saveData(d) { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(d)); } catch {} }
const defaultState = { tricks: [], scripts: [], setlists: [], gigs: [], notes: [] };
let _id = Date.now();
const uid = () => `${++_id}`;

// ─── Geo search ───
function usePlacesSearch() {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const search = useCallback(async (q) => {
    if (!q || q.length < 3) { setResults([]); return; }
    setLoading(true);
    try {
      const r = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q)}&format=json&addressdetails=1&limit=5`);
      const d = await r.json();
      setResults(d.map(x => ({ name: x.display_name?.split(",").slice(0, 3).join(","), full: x.display_name, lat: +x.lat, lng: +x.lon, city: x.address?.city || x.address?.town || x.address?.village || "", state: x.address?.state || "", country: x.address?.country || "" })));
    } catch { setResults([]); }
    setLoading(false);
  }, []);
  return { results, search, loading, clear: () => setResults([]) };
}

// ─── Contact enrichment ───
async function enrichContact(email) {
  if (!email?.includes("@")) return null;
  try {
    const domain = email.split("@")[1];
    const nameGuess = email.split("@")[0].replace(/[._-]/g, " ").replace(/\b\w/g, c => c.toUpperCase());
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000,
        tools: [{ type: "web_search_20250305", name: "web_search" }],
        messages: [{ role: "user", content: `Look up "${email}". Return ONLY JSON: { "fullName": "", "linkedIn": "", "position": "", "company": "", "phone": "" }. Guess name from "${nameGuess}", company from "${domain}" if needed.` }] })
    });
    const d = await r.json();
    const t = d.content?.map(c => c.text || "").join("") || "";
    return JSON.parse(t.replace(/```json|```/g, "").trim());
  } catch {
    const domain = email.split("@")[1];
    return { fullName: email.split("@")[0].replace(/[._-]/g, " ").replace(/\b\w/g, c => c.toUpperCase()), linkedIn: "", position: "", company: domain?.split(".")[0]?.replace(/\b\w/g, c => c.toUpperCase()) || "", phone: "" };
  }
}

// ─── Shared UI ───
function Modal({ open, onClose, title, children, wide }) {
  if (!open) return null;
  return (<div style={S.overlay} onClick={onClose}>
    <div style={{ ...S.modal, maxWidth: wide ? 740 : 620 }} onClick={e => e.stopPropagation()}>
      <div style={S.modalHeader}><h2 style={S.modalTitle}>{title}</h2><button onClick={onClose} style={S.closeBtn}>✕</button></div>
      <div style={S.modalBody}>{children}</div>
    </div>
  </div>);
}
function Badge({ label, color = "#c9a227" }) { return <span style={{ ...S.badge, background: color + "22", color, border: `1px solid ${color}44` }}>{label}</span>; }
function Stars({ value, onChange, max = 5 }) {
  return (<div style={{ display: "flex", gap: 4, cursor: onChange ? "pointer" : "default" }}>
    {Array.from({ length: max }, (_, i) => <span key={i} onClick={() => onChange?.(i + 1)} style={{ color: i < value ? "#c9a227" : "#444", fontSize: 20, userSelect: "none" }}>★</span>)}
    {value > 0 && <span style={{ fontSize: 11, color: "#999", marginLeft: 6, alignSelf: "center" }}>{REACTION_LABELS[value]}</span>}
  </div>);
}
function Field({ label, children }) { return <label style={S.field}><span style={S.fieldLabel}>{label}</span>{children}</label>; }
function Input(p) { return <input {...p} style={{ ...S.input, ...p.style }} />; }
function Textarea(p) { return <textarea {...p} style={{ ...S.textarea, ...p.style }} />; }
function Select({ options, placeholder, ...p }) { return <select {...p} style={{ ...S.input, ...p.style }}>{placeholder && <option value="">{placeholder}</option>}{options.map(o => <option key={o} value={o}>{o}</option>)}</select>; }
function TagPicker({ tags, selected, onToggle }) {
  return <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>{tags.map(t => {
    const a = selected.includes(t);
    return <button key={t} onClick={() => onToggle(t)} style={{ ...S.tagBtn, background: a ? "#c9a22733" : "#1a1a1a", color: a ? "#c9a227" : "#888", border: `1px solid ${a ? "#c9a227" : "#333"}` }}>{t}</button>;
  })}</div>;
}
function EmptyState({ icon, text }) { return <div style={{ textAlign: "center", padding: "60px 20px", color: "#555" }}><div style={{ fontSize: 48, marginBottom: 12 }}>{icon}</div><div style={{ fontSize: 14 }}>{text}</div></div>; }
function SearchBar({ value, onChange, placeholder }) {
  return <div style={S.searchWrap}><span style={S.searchIcon}>⌕</span><input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={S.searchInput} />{value && <button onClick={() => onChange("")} style={S.searchClear}>✕</button>}</div>;
}
function Divider({ label, color = "#c9a227" }) { return <div style={{ borderTop: `1px solid ${color}33`, paddingTop: 14, marginTop: 14, marginBottom: 10 }}><span style={{ ...S.fieldLabel, color, fontSize: 11, letterSpacing: 1.2 }}>{label}</span></div>; }

// ─── Venue Search ───
function VenueSearch({ value, fullAddr, onSelect, onChange }) {
  const { results, search, loading, clear } = usePlacesSearch();
  const [show, setShow] = useState(false);
  const t = useRef();
  const handle = v => { onChange(v); clearTimeout(t.current); t.current = setTimeout(() => search(v), 350); setShow(true); };
  return (<div style={{ position: "relative" }}>
    <Input value={value || ""} onChange={e => handle(e.target.value)} placeholder="Search venue or address..." onFocus={() => results.length && setShow(true)} onBlur={() => setTimeout(() => setShow(false), 200)} />
    {loading && <span style={{ position: "absolute", right: 10, top: 9, fontSize: 11, color: "#666" }}>...</span>}
    {show && results.length > 0 && <div style={S.dropdown}>{results.map((s, i) => <div key={i} style={S.dropItem} onMouseDown={() => { onSelect(s); setShow(false); clear(); }}><div style={{ fontSize: 13, color: "#ddd" }}>{s.name}</div><div style={{ fontSize: 11, color: "#666" }}>{s.city}{s.state ? `, ${s.state}` : ""}</div></div>)}</div>}
    {fullAddr && <div style={{ fontSize: 11, color: "#555", marginTop: 4 }}>📍 {fullAddr}</div>}
  </div>);
}

// ─── Contact Section ───
function ContactSection({ form, setForm }) {
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const lookup = async () => {
    if (!form.contactEmail || done) return;
    setBusy(true);
    const info = await enrichContact(form.contactEmail);
    if (info) setForm(f => ({ ...f, contactName: f.contactName || info.fullName, contactLinkedIn: f.contactLinkedIn || info.linkedIn, contactPosition: f.contactPosition || info.position, contactCompany: f.contactCompany || info.company, contactPhone: f.contactPhone || info.phone }));
    setDone(true); setBusy(false);
  };
  return (<div>
    <Divider label="✦ Contact" />
    <Field label="Email (auto-fills on blur)"><div style={{ position: "relative" }}><Input value={form.contactEmail || ""} onChange={e => { setForm({ ...form, contactEmail: e.target.value }); setDone(false); }} onBlur={lookup} placeholder="jane@company.com" />{busy && <span style={{ position: "absolute", right: 10, top: 9, fontSize: 11, color: "#c9a227" }}>Looking up...</span>}</div></Field>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
      <Field label="Full Name"><Input value={form.contactName || ""} onChange={e => setForm({ ...form, contactName: e.target.value })} /></Field>
      <Field label="Phone"><Input value={form.contactPhone || ""} onChange={e => setForm({ ...form, contactPhone: e.target.value })} /></Field>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
      <Field label="Position"><Input value={form.contactPosition || ""} onChange={e => setForm({ ...form, contactPosition: e.target.value })} /></Field>
      <Field label="Company"><Input value={form.contactCompany || ""} onChange={e => setForm({ ...form, contactCompany: e.target.value })} /></Field>
    </div>
    <Field label="LinkedIn"><Input value={form.contactLinkedIn || ""} onChange={e => setForm({ ...form, contactLinkedIn: e.target.value })} /></Field>
    {done && <div style={{ fontSize: 11, color: "#22c955", marginTop: -6, marginBottom: 8 }}>✓ Auto-filled</div>}
  </div>);
}

// ─── Expense Tracker ───
function ExpenseTracker({ expenses = [], onChange }) {
  const add = () => onChange([...expenses, { id: uid(), category: "Travel", description: "", amount: "", receipt: "", reimbursable: false, reimbursed: false }]);
  const upd = (i, k, v) => { const e = [...expenses]; e[i] = { ...e[i], [k]: v }; onChange(e); };
  const rm = i => onChange(expenses.filter((_, j) => j !== i));
  const total = expenses.reduce((s, e) => s + (+e.amount || 0), 0);
  const reimbAmt = expenses.filter(e => e.reimbursable).reduce((s, e) => s + (+e.amount || 0), 0);
  const reimbDone = expenses.filter(e => e.reimbursed).reduce((s, e) => s + (+e.amount || 0), 0);
  return (<div>
    <Divider label="✦ Expenses & Receipts" />
    {expenses.length > 0 && <div style={{ display: "flex", gap: 16, marginBottom: 12, flexWrap: "wrap", fontSize: 12 }}>
      <span style={{ color: "#ff6b6b" }}>Total: ${total.toFixed(2)}</span>
      {reimbAmt > 0 && <span style={{ color: "#6b8afd" }}>Reimbursable: ${reimbAmt.toFixed(2)}</span>}
      {reimbAmt - reimbDone > 0 && <span style={{ color: "#ffa94d" }}>Pending: ${(reimbAmt - reimbDone).toFixed(2)}</span>}
    </div>}
    {expenses.map((exp, i) => <div key={exp.id || i} style={{ background: "#0a0a0a", border: "1px solid #1e1e1e", borderRadius: 8, padding: 10, marginBottom: 6 }}>
      <div style={{ display: "flex", gap: 6, marginBottom: 4, alignItems: "center" }}>
        <select value={exp.category} onChange={e => upd(i, "category", e.target.value)} style={{ ...S.input, width: 110, flex: "none" }}>{EXPENSE_CATS.map(c => <option key={c}>{c}</option>)}</select>
        <Input value={exp.description || ""} onChange={e => upd(i, "description", e.target.value)} placeholder="Description" style={{ flex: 1 }} />
        <div style={{ position: "relative", width: 85, flex: "none" }}><span style={{ position: "absolute", left: 8, top: 9, color: "#666", fontSize: 12 }}>$</span><Input type="number" value={exp.amount || ""} onChange={e => upd(i, "amount", e.target.value)} style={{ paddingLeft: 20, width: "100%" }} /></div>
        <button onClick={() => rm(i)} style={{ ...S.delBtn, position: "static" }}>✕</button>
      </div>
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
        <Input value={exp.receipt || ""} onChange={e => upd(i, "receipt", e.target.value)} placeholder="Receipt # or URL" style={{ flex: 1, fontSize: 11 }} />
        <label style={{ display: "flex", gap: 4, alignItems: "center", fontSize: 11, color: "#888", cursor: "pointer", whiteSpace: "nowrap" }}><input type="checkbox" checked={exp.reimbursable || false} onChange={e => upd(i, "reimbursable", e.target.checked)} />Reimb.</label>
        {exp.reimbursable && <label style={{ display: "flex", gap: 4, alignItems: "center", fontSize: 11, color: exp.reimbursed ? "#22c955" : "#888", cursor: "pointer", whiteSpace: "nowrap" }}><input type="checkbox" checked={exp.reimbursed || false} onChange={e => upd(i, "reimbursed", e.target.checked)} />{exp.reimbursed ? "Done ✓" : "Pending"}</label>}
      </div>
    </div>)}
    <button onClick={add} style={{ ...S.tagBtn, color: "#c9a227", borderColor: "#c9a227", marginTop: 4 }}>+ Add Expense</button>
  </div>);
}

// ─── Follow-ups ───
function FollowUps({ items = [], onChange }) {
  const add = () => onChange([...items, { id: uid(), type: "Follow Up", date: "", note: "", done: false }]);
  const upd = (i, k, v) => { const a = [...items]; a[i] = { ...a[i], [k]: v }; onChange(a); };
  const rm = i => onChange(items.filter((_, j) => j !== i));
  return (<div>
    <Divider label="✦ Follow-ups & Tasks" />
    {items.map((it, i) => <div key={it.id || i} style={{ display: "flex", gap: 6, marginBottom: 6, alignItems: "center" }}>
      <input type="checkbox" checked={it.done} onChange={e => upd(i, "done", e.target.checked)} />
      <select value={it.type} onChange={e => upd(i, "type", e.target.value)} style={{ ...S.input, width: 130, flex: "none" }}>{FOLLOWUP_TYPES.map(t => <option key={t}>{t}</option>)}</select>
      <Input type="date" value={it.date || ""} onChange={e => upd(i, "date", e.target.value)} style={{ width: 130, flex: "none" }} />
      <Input value={it.note || ""} onChange={e => upd(i, "note", e.target.value)} placeholder="Note..." style={{ flex: 1 }} />
      <button onClick={() => rm(i)} style={{ ...S.delBtn, position: "static" }}>✕</button>
    </div>)}
    <button onClick={add} style={{ ...S.tagBtn, color: "#6b8afd", borderColor: "#6b8afd", marginTop: 4 }}>+ Add Follow-up</button>
  </div>);
}

// ─── Invoice Generator ───
function InvoiceModal({ gig, open, onClose }) {
  if (!open || !gig) return null;
  const fee = +gig.fee || 0;
  const expenses = (gig.expenses || []).filter(e => e.reimbursable);
  const reimbTotal = expenses.reduce((s, e) => s + (+e.amount || 0), 0);
  const total = fee + reimbTotal;
  const invNum = `INV-${(gig.date || "").replace(/-/g, "")}-${gig.id?.slice(-4) || "0000"}`;
  const today = new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });

  const printInvoice = () => {
    const w = window.open("", "_blank");
    w.document.write(`<!DOCTYPE html><html><head><title>Invoice ${invNum}</title><style>
      body{font-family:Helvetica,Arial,sans-serif;max-width:700px;margin:40px auto;padding:20px;color:#222}
      h1{font-size:28px;margin:0 0 4px;color:#111}.inv-num{color:#888;font-size:14px}
      .header{display:flex;justify-content:space-between;margin-bottom:40px;padding-bottom:20px;border-bottom:2px solid #c9a227}
      table{width:100%;border-collapse:collapse;margin:20px 0}th{text-align:left;padding:8px 12px;background:#f5f5f5;font-size:13px;border-bottom:2px solid #ddd}
      td{padding:8px 12px;border-bottom:1px solid #eee;font-size:13px}.right{text-align:right}
      .total-row td{font-weight:700;font-size:16px;border-top:2px solid #c9a227;padding-top:12px}
      .footer{margin-top:40px;padding-top:20px;border-top:1px solid #eee;font-size:12px;color:#888}
      .from{font-size:13px;color:#555}
    </style></head><body>
    <div class="header"><div><h1>INVOICE</h1><div class="inv-num">${invNum}</div><div style="margin-top:8px;font-size:13px;color:#555">Date: ${today}</div></div>
    <div style="text-align:right"><div style="font-size:18px;font-weight:700">Anna DeGuzman</div><div class="from">UP MY SLEEVES LLC</div></div></div>
    <div style="margin-bottom:20px"><strong>Bill To:</strong><br>${gig.contactName || gig.client || "Client"}<br>${gig.contactCompany ? gig.contactCompany + "<br>" : ""}${gig.contactEmail || ""}</div>
    <div style="margin-bottom:8px"><strong>Event:</strong> ${gig.client || ""} — ${gig.date ? new Date(gig.date + "T12:00").toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }) : ""}</div>
    ${gig.venue ? `<div style="margin-bottom:20px"><strong>Venue:</strong> ${gig.venue}</div>` : ""}
    <table><tr><th>Description</th><th class="right">Amount</th></tr>
    <tr><td>Performance Fee — ${gig.venueType || "Live Performance"}</td><td class="right">$${fee.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td></tr>
    ${expenses.map(e => `<tr><td>Reimbursable: ${e.category}${e.description ? " — " + e.description : ""}</td><td class="right">$${(+e.amount || 0).toFixed(2)}</td></tr>`).join("")}
    <tr class="total-row"><td>Total Due</td><td class="right">$${total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td></tr></table>
    <div class="footer"><p>Payment due within 30 days of invoice date.</p><p>Thank you for your business!</p></div>
    </body></html>`);
    w.document.close();
    w.print();
  };

  return (<Modal open={open} onClose={onClose} title="Invoice Preview">
    <div style={{ background: "#fff", color: "#222", borderRadius: 8, padding: 24, fontSize: 13 }}>
      <div style={{ display: "flex", justifyContent: "space-between", borderBottom: "2px solid #c9a227", paddingBottom: 16, marginBottom: 20 }}>
        <div><div style={{ fontSize: 22, fontWeight: 700 }}>INVOICE</div><div style={{ color: "#888", fontSize: 12 }}>{invNum}</div><div style={{ fontSize: 12, color: "#555", marginTop: 4 }}>Date: {today}</div></div>
        <div style={{ textAlign: "right" }}><div style={{ fontSize: 16, fontWeight: 700 }}>Anna DeGuzman</div><div style={{ color: "#555", fontSize: 12 }}>UP MY SLEEVES LLC</div></div>
      </div>
      <div style={{ marginBottom: 12 }}><strong>Bill To:</strong> {gig.contactName || gig.client}{gig.contactCompany && ` — ${gig.contactCompany}`}</div>
      <div style={{ marginBottom: 16 }}><strong>Event:</strong> {gig.client} — {gig.date && new Date(gig.date + "T12:00").toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</div>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead><tr style={{ background: "#f5f5f5" }}><th style={{ padding: "8px 12px", textAlign: "left", borderBottom: "2px solid #ddd" }}>Description</th><th style={{ padding: "8px 12px", textAlign: "right", borderBottom: "2px solid #ddd" }}>Amount</th></tr></thead>
        <tbody>
          <tr><td style={{ padding: "8px 12px", borderBottom: "1px solid #eee" }}>Performance Fee</td><td style={{ padding: "8px 12px", textAlign: "right", borderBottom: "1px solid #eee" }}>${fee.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td></tr>
          {expenses.map((e, i) => <tr key={i}><td style={{ padding: "8px 12px", borderBottom: "1px solid #eee" }}>Reimb: {e.category}{e.description ? ` — ${e.description}` : ""}</td><td style={{ padding: "8px 12px", textAlign: "right", borderBottom: "1px solid #eee" }}>${(+e.amount || 0).toFixed(2)}</td></tr>)}
          <tr><td style={{ padding: "12px", fontWeight: 700, fontSize: 15, borderTop: "2px solid #c9a227" }}>Total Due</td><td style={{ padding: "12px", textAlign: "right", fontWeight: 700, fontSize: 15, borderTop: "2px solid #c9a227" }}>${total.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td></tr>
        </tbody>
      </table>
    </div>
    <button onClick={printInvoice} style={{ ...S.saveBtn, marginTop: 12 }}>Print / Save as PDF</button>
  </Modal>);
}

// ─── Calendar View ───
function CalendarView({ gigs }) {
  const [month, setMonth] = useState(() => { const d = new Date(); return { y: d.getFullYear(), m: d.getMonth() }; });
  const daysInMonth = new Date(month.y, month.m + 1, 0).getDate();
  const firstDay = new Date(month.y, month.m, 1).getDay();
  const monthLabel = new Date(month.y, month.m).toLocaleDateString("en-US", { month: "long", year: "numeric" });
  const prev = () => setMonth(m => m.m === 0 ? { y: m.y - 1, m: 11 } : { ...m, m: m.m - 1 });
  const next = () => setMonth(m => m.m === 11 ? { y: m.y + 1, m: 0 } : { ...m, m: m.m + 1 });

  const gigsByDate = useMemo(() => {
    const map = {};
    gigs.forEach(g => { if (g.date) { const d = g.date.slice(0, 10); map[d] = [...(map[d] || []), g]; } });
    return map;
  }, [gigs]);

  const cells = [];
  for (let i = 0; i < firstDay; i++) cells.push(<div key={`e${i}`} style={S.calCell} />);
  for (let d = 1; d <= daysInMonth; d++) {
    const key = `${month.y}-${String(month.m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
    const dayGigs = gigsByDate[key] || [];
    const isToday = key === new Date().toISOString().slice(0, 10);
    cells.push(<div key={d} style={{ ...S.calCell, background: isToday ? "#c9a22711" : "transparent", border: isToday ? "1px solid #c9a22744" : "1px solid #1a1a1a" }}>
      <div style={{ fontSize: 12, color: isToday ? "#c9a227" : "#777", marginBottom: 2 }}>{d}</div>
      {dayGigs.map(g => {
        const stage = PIPELINE.find(p => p.key === g.stage) || PIPELINE[0];
        return <div key={g.id} style={{ fontSize: 10, padding: "2px 4px", borderRadius: 4, background: stage.color + "22", color: stage.color, marginBottom: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", cursor: "default" }} title={`${g.client} — ${stage.label}`}>{g.client}</div>;
      })}
    </div>);
  }

  return (<div>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
      <button onClick={prev} style={S.utilBtn}>◀</button>
      <div style={{ fontFamily: "'Playfair Display', serif", fontSize: 18, fontWeight: 600 }}>{monthLabel}</div>
      <button onClick={next} style={S.utilBtn}>▶</button>
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2, marginBottom: 4 }}>
      {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map(d => <div key={d} style={{ fontSize: 11, color: "#555", textAlign: "center", padding: 4 }}>{d}</div>)}
    </div>
    <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2 }}>{cells}</div>
  </div>);
}

// ─── TRICKS TAB ───
function TricksTab({ tricks, setTricks }) {
  const [modal, setModal] = useState(false); const [editing, setEditing] = useState(null); const [search, setSearch] = useState(""); const [fCat, setFCat] = useState(""); const [fVen, setFVen] = useState(""); const [form, setForm] = useState({});
  const openNew = () => { setForm({ name: "", category: "Card Magic", difficulty: "Intermediate", props: "", resetTime: "", venues: [], reaction: 0, methodNotes: "", performanceNotes: "" }); setEditing(null); setModal(true); };
  const openEdit = t => { setForm({ ...t }); setEditing(t.id); setModal(true); };
  const save = () => { if (!form.name?.trim()) return; if (editing) setTricks(p => p.map(t => t.id === editing ? { ...form, id: editing } : t)); else setTricks(p => [...p, { ...form, id: uid() }]); setModal(false); };
  const rm = id => setTricks(p => p.filter(t => t.id !== id));
  const filtered = tricks.filter(t => { if (search && !t.name.toLowerCase().includes(search.toLowerCase())) return false; if (fCat && t.category !== fCat) return false; if (fVen && !(t.venues || []).includes(fVen)) return false; return true; });
  return (<div>
    <div style={S.tabBar}><SearchBar value={search} onChange={setSearch} placeholder="Search tricks..." /><div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}><Select options={CATEGORIES} placeholder="All" value={fCat} onChange={e => setFCat(e.target.value)} style={{ width: "auto", minWidth: 120 }} /><Select options={VENUE_TYPES} placeholder="All Venues" value={fVen} onChange={e => setFVen(e.target.value)} style={{ width: "auto", minWidth: 120 }} /><button onClick={openNew} style={S.addBtn}>+ Add Trick</button></div></div>
    {filtered.length === 0 ? <EmptyState icon="🃏" text="Add your first trick" /> : <div style={S.grid}>{filtered.map(t => <div key={t.id} style={S.card} onClick={() => openEdit(t)}><div style={{ display: "flex", justifyContent: "space-between" }}><div><div style={S.cardTitle}>{t.name}</div><div style={S.cardSub}>{t.category} · {t.difficulty}</div></div><button onClick={e => { e.stopPropagation(); rm(t.id); }} style={S.delBtn}>✕</button></div><Stars value={t.reaction || 0} />{t.props && <div style={S.cardDetail}>Props: {t.props}</div>}<div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginTop: 6 }}>{(t.venues || []).map(v => <Badge key={v} label={v} />)}</div></div>)}</div>}
    <Modal open={modal} onClose={() => setModal(false)} title={editing ? "Edit Trick" : "New Trick"}>
      <Field label="Name"><Input value={form.name || ""} onChange={e => setForm({ ...form, name: e.target.value })} /></Field>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}><Field label="Category"><Select options={CATEGORIES} value={form.category || ""} onChange={e => setForm({ ...form, category: e.target.value })} /></Field><Field label="Difficulty"><Select options={DIFFICULTY} value={form.difficulty || ""} onChange={e => setForm({ ...form, difficulty: e.target.value })} /></Field></div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}><Field label="Props"><Input value={form.props || ""} onChange={e => setForm({ ...form, props: e.target.value })} /></Field><Field label="Reset Time"><Input value={form.resetTime || ""} onChange={e => setForm({ ...form, resetTime: e.target.value })} /></Field></div>
      <Field label="Reaction"><Stars value={form.reaction || 0} onChange={v => setForm({ ...form, reaction: v })} /></Field>
      <Field label="Venues"><TagPicker tags={VENUE_TYPES} selected={form.venues || []} onToggle={v => setForm({ ...form, venues: (form.venues || []).includes(v) ? form.venues.filter(x => x !== v) : [...(form.venues || []), v] })} /></Field>
      <Field label="Method Notes"><Textarea value={form.methodNotes || ""} onChange={e => setForm({ ...form, methodNotes: e.target.value })} rows={3} /></Field>
      <Field label="Performance Notes"><Textarea value={form.performanceNotes || ""} onChange={e => setForm({ ...form, performanceNotes: e.target.value })} rows={3} /></Field>
      <button onClick={save} style={S.saveBtn}>Save</button>
    </Modal>
  </div>);
}

// ─── SCRIPTS TAB ───
function ScriptsTab({ scripts, setScripts }) {
  const [modal, setModal] = useState(false); const [editing, setEditing] = useState(null); const [search, setSearch] = useState(""); const [form, setForm] = useState({});
  const openNew = () => { setForm({ trickName: "", hook: "", patter: "", callbacks: "" }); setEditing(null); setModal(true); };
  const openEdit = s => { setForm({ ...s }); setEditing(s.id); setModal(true); };
  const save = () => { if (!form.trickName?.trim()) return; if (editing) setScripts(p => p.map(s => s.id === editing ? { ...form, id: editing } : s)); else setScripts(p => [...p, { ...form, id: uid() }]); setModal(false); };
  const rm = id => setScripts(p => p.filter(s => s.id !== id));
  const filtered = scripts.filter(s => !search || s.trickName.toLowerCase().includes(search.toLowerCase()));
  return (<div>
    <div style={S.tabBar}><SearchBar value={search} onChange={setSearch} placeholder="Search scripts..." /><button onClick={openNew} style={S.addBtn}>+ Add Script</button></div>
    {filtered.length === 0 ? <EmptyState icon="📝" text="Store hooks, patter, and callbacks" /> : <div style={S.grid}>{filtered.map(s => <div key={s.id} style={S.card} onClick={() => openEdit(s)}><div style={{ display: "flex", justifyContent: "space-between" }}><div style={S.cardTitle}>{s.trickName}</div><button onClick={e => { e.stopPropagation(); rm(s.id); }} style={S.delBtn}>✕</button></div>{s.hook && <div style={{ ...S.cardDetail, color: "#c9a227", fontStyle: "italic" }}>"{s.hook}"</div>}{s.patter && <div style={{ ...S.cardDetail, whiteSpace: "pre-wrap", maxHeight: 80, overflow: "hidden" }}>{s.patter}</div>}</div>)}</div>}
    <Modal open={modal} onClose={() => setModal(false)} title={editing ? "Edit Script" : "New Script"}>
      <Field label="Trick Name"><Input value={form.trickName || ""} onChange={e => setForm({ ...form, trickName: e.target.value })} /></Field>
      <Field label="Hook"><Input value={form.hook || ""} onChange={e => setForm({ ...form, hook: e.target.value })} /></Field>
      <Field label="Patter"><Textarea value={form.patter || ""} onChange={e => setForm({ ...form, patter: e.target.value })} rows={6} /></Field>
      <Field label="Callbacks"><Textarea value={form.callbacks || ""} onChange={e => setForm({ ...form, callbacks: e.target.value })} rows={3} /></Field>
      <button onClick={save} style={S.saveBtn}>Save</button>
    </Modal>
  </div>);
}

// ─── SETLISTS TAB ───
function SetlistsTab({ setlists, setSetlists }) {
  const [modal, setModal] = useState(false); const [editing, setEditing] = useState(null); const [form, setForm] = useState({});
  const openNew = () => { setForm({ name: "", venue: "", duration: "", items: [], notes: "" }); setEditing(null); setModal(true); };
  const openEdit = s => { setForm({ ...s }); setEditing(s.id); setModal(true); };
  const save = () => { if (!form.name?.trim()) return; if (editing) setSetlists(p => p.map(s => s.id === editing ? { ...form, id: editing } : s)); else setSetlists(p => [...p, { ...form, id: uid() }]); setModal(false); };
  const rm = id => setSetlists(p => p.filter(s => s.id !== id));
  const addItem = () => setForm({ ...form, items: [...(form.items || []), { name: "", duration: "" }] });
  const updItem = (i, k, v) => { const it = [...form.items]; it[i] = { ...it[i], [k]: v }; setForm({ ...form, items: it }); };
  const rmItem = i => setForm({ ...form, items: form.items.filter((_, j) => j !== i) });
  const mv = (f, t) => { if (t < 0 || t >= form.items.length) return; const it = [...form.items]; const [m] = it.splice(f, 1); it.splice(t, 0, m); setForm({ ...form, items: it }); };
  return (<div>
    <div style={S.tabBar}><div style={{ color: "#888", fontSize: 13 }}>{setlists.length} setlist{setlists.length !== 1 ? "s" : ""}</div><button onClick={openNew} style={S.addBtn}>+ New Setlist</button></div>
    {setlists.length === 0 ? <EmptyState icon="📋" text="Build show setlists" /> : <div style={S.grid}>{setlists.map(s => <div key={s.id} style={S.card} onClick={() => openEdit(s)}><div style={{ display: "flex", justifyContent: "space-between" }}><div style={S.cardTitle}>{s.name}</div><button onClick={e => { e.stopPropagation(); rm(s.id); }} style={S.delBtn}>✕</button></div>{s.venue && <Badge label={s.venue} />}{s.duration && <div style={S.cardDetail}>{s.duration}</div>}<div style={{ marginTop: 6 }}>{(s.items || []).map((it, i) => <div key={i} style={{ fontSize: 12, color: "#aaa", padding: "1px 0" }}><span style={{ color: "#c9a227", marginRight: 6 }}>{i + 1}.</span>{it.name || "?"}{it.duration && <span style={{ color: "#555", marginLeft: 4 }}>({it.duration})</span>}</div>)}</div></div>)}</div>}
    <Modal open={modal} onClose={() => setModal(false)} title={editing ? "Edit Setlist" : "New Setlist"}>
      <Field label="Name"><Input value={form.name || ""} onChange={e => setForm({ ...form, name: e.target.value })} /></Field>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}><Field label="Venue Type"><Select options={VENUE_TYPES} placeholder="Select..." value={form.venue || ""} onChange={e => setForm({ ...form, venue: e.target.value })} /></Field><Field label="Duration"><Input value={form.duration || ""} onChange={e => setForm({ ...form, duration: e.target.value })} /></Field></div>
      <div style={{ marginBottom: 12 }}><div style={{ ...S.fieldLabel, marginBottom: 8 }}>Set Order</div>{(form.items || []).map((it, i) => <div key={i} style={{ display: "flex", gap: 6, marginBottom: 6, alignItems: "center" }}><div style={{ display: "flex", flexDirection: "column", gap: 2 }}><button onClick={() => mv(i, i - 1)} style={S.arrowBtn} disabled={i === 0}>▲</button><button onClick={() => mv(i, i + 1)} style={S.arrowBtn} disabled={i === form.items.length - 1}>▼</button></div><span style={{ color: "#c9a227", fontSize: 13, minWidth: 20 }}>{i + 1}.</span><Input value={it.name} onChange={e => updItem(i, "name", e.target.value)} placeholder="Trick" style={{ flex: 1 }} /><Input value={it.duration || ""} onChange={e => updItem(i, "duration", e.target.value)} placeholder="Time" style={{ width: 70 }} /><button onClick={() => rmItem(i)} style={{ ...S.delBtn, position: "static" }}>✕</button></div>)}<button onClick={addItem} style={{ ...S.tagBtn, color: "#c9a227", borderColor: "#c9a227" }}>+ Add</button></div>
      <Field label="Notes"><Textarea value={form.notes || ""} onChange={e => setForm({ ...form, notes: e.target.value })} rows={3} /></Field>
      <button onClick={save} style={S.saveBtn}>Save</button>
    </Modal>
  </div>);
}

// ─── GIGS TAB (FULL CRM) ───
function GigsTab({ gigs, setGigs }) {
  const [modal, setModal] = useState(false); const [editing, setEditing] = useState(null); const [search, setSearch] = useState("");
  const [form, setForm] = useState({}); const [view, setView] = useState("pipeline"); const [filterStage, setFilterStage] = useState("");
  const [invGig, setInvGig] = useState(null);

  const blankGig = { client: "", date: "", venue: "", venueAddress: "", venueCity: "", venueState: "", venueType: "", fee: "", stage: "inquiry", expenses: [], followups: [], setlist: "", contactEmail: "", contactName: "", contactPhone: "", contactPosition: "", contactCompany: "", contactLinkedIn: "", notes: "", rating: 0 };
  const openNew = (stage = "inquiry") => { setForm({ ...blankGig, stage }); setEditing(null); setModal(true); };
  const openEdit = g => { setForm({ ...g }); setEditing(g.id); setModal(true); };
  const save = () => { if (!form.client?.trim()) return; if (editing) setGigs(p => p.map(g => g.id === editing ? { ...form, id: editing } : g)); else setGigs(p => [...p, { ...form, id: uid() }]); setModal(false); };
  const rm = id => setGigs(p => p.filter(g => g.id !== id));
  const moveStage = (id, stage) => setGigs(p => p.map(g => g.id === id ? { ...g, stage } : g));

  const filtered = gigs.filter(g => { if (search && !g.client.toLowerCase().includes(search.toLowerCase()) && !(g.venue || "").toLowerCase().includes(search.toLowerCase()) && !(g.contactCompany || "").toLowerCase().includes(search.toLowerCase())) return false; if (filterStage && g.stage !== filterStage) return false; return true; });

  const totalRev = gigs.filter(g => ["booked", "completed", "paid"].includes(g.stage)).reduce((s, g) => s + (+g.fee || 0), 0);
  const totalExp = gigs.reduce((s, g) => s + (g.expenses || []).reduce((es, e) => es + (+e.amount || 0), 0), 0);
  const pending = gigs.filter(g => ["inquiry", "negotiating"].includes(g.stage)).reduce((s, g) => s + (+g.fee || 0), 0);
  const gigExp = g => (g.expenses || []).reduce((s, e) => s + (+e.amount || 0), 0);

  const upcomingFollowups = gigs.flatMap(g => (g.followups || []).filter(f => !f.done && f.date).map(f => ({ ...f, gig: g }))).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 5);

  return (<div>
    {/* Dashboard */}
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))", gap: 8, marginBottom: 16 }}>
      <div style={S.statCard}><div style={S.statLabel}>Pipeline</div><div style={{ ...S.statVal, color: "#ffa94d" }}>${pending.toLocaleString()}</div></div>
      <div style={S.statCard}><div style={S.statLabel}>Booked Rev</div><div style={{ ...S.statVal, color: "#c9a227" }}>${totalRev.toLocaleString()}</div></div>
      <div style={S.statCard}><div style={S.statLabel}>Expenses</div><div style={{ ...S.statVal, color: "#ff6b6b" }}>-${totalExp.toLocaleString()}</div></div>
      <div style={S.statCard}><div style={S.statLabel}>Net</div><div style={{ ...S.statVal, color: totalRev - totalExp >= 0 ? "#22c955" : "#ff6b6b" }}>${(totalRev - totalExp).toLocaleString()}</div></div>
      <div style={S.statCard}><div style={S.statLabel}>Gigs</div><div style={{ ...S.statVal, color: "#ddd" }}>{gigs.length}</div></div>
    </div>

    {/* Upcoming follow-ups */}
    {upcomingFollowups.length > 0 && <div style={{ background: "#111", border: "1px solid #1e1e1e", borderRadius: 10, padding: 14, marginBottom: 16 }}>
      <div style={{ ...S.fieldLabel, color: "#6b8afd", marginBottom: 8 }}>Upcoming Follow-ups</div>
      {upcomingFollowups.map((f, i) => <div key={i} style={{ fontSize: 12, color: "#aaa", padding: "3px 0", display: "flex", gap: 8 }}>
        <span style={{ color: "#555" }}>{new Date(f.date + "T12:00").toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
        <Badge label={f.type} color="#6b8afd" />
        <span>{f.gig.client}</span>
        {f.note && <span style={{ color: "#555" }}>— {f.note}</span>}
      </div>)}
    </div>}

    {/* View toggles + controls */}
    <div style={S.tabBar}>
      <div style={{ display: "flex", gap: 4 }}>
        {[{ k: "pipeline", l: "Pipeline" }, { k: "list", l: "List" }, { k: "calendar", l: "Calendar" }].map(v => <button key={v.k} onClick={() => setView(v.k)} style={{ ...S.tagBtn, color: view === v.k ? "#c9a227" : "#666", borderColor: view === v.k ? "#c9a227" : "#333", background: view === v.k ? "#c9a22722" : "#1a1a1a" }}>{v.l}</button>)}
      </div>
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <SearchBar value={search} onChange={setSearch} placeholder="Search..." />
        <button onClick={() => openNew()} style={S.addBtn}>+ New Gig</button>
      </div>
    </div>

    {/* Pipeline View */}
    {view === "pipeline" && <div style={{ display: "grid", gridTemplateColumns: `repeat(${PIPELINE.length}, minmax(140px, 1fr))`, gap: 8, overflowX: "auto" }}>
      {PIPELINE.map(stage => {
        const stageGigs = filtered.filter(g => (g.stage || "inquiry") === stage.key);
        return (<div key={stage.key} style={{ background: "#0d0d0d", borderRadius: 10, border: `1px solid ${stage.color}22`, minHeight: 200 }}>
          <div style={{ padding: "10px 12px 8px", borderBottom: `2px solid ${stage.color}33`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: stage.color }}>{stage.icon} {stage.label}</span>
            <span style={{ fontSize: 11, color: "#555" }}>{stageGigs.length}</span>
          </div>
          <div style={{ padding: 6 }}>
            {stageGigs.map(g => <div key={g.id} style={{ background: "#111", border: "1px solid #1e1e1e", borderRadius: 8, padding: 10, marginBottom: 6, cursor: "pointer" }} onClick={() => openEdit(g)}>
              <div style={{ fontSize: 13, fontWeight: 600, color: "#ddd", marginBottom: 2 }}>{g.client}</div>
              {g.date && <div style={{ fontSize: 11, color: "#666" }}>{new Date(g.date + "T12:00").toLocaleDateString("en-US", { month: "short", day: "numeric" })}</div>}
              {g.fee && <div style={{ fontSize: 13, color: "#c9a227", fontWeight: 600 }}>${(+g.fee).toLocaleString()}</div>}
              {g.venueCity && <div style={{ fontSize: 10, color: "#555" }}>{g.venueCity}</div>}
            </div>)}
            <button onClick={() => openNew(stage.key)} style={{ ...S.tagBtn, width: "100%", textAlign: "center", color: stage.color, borderColor: stage.color + "44", fontSize: 11, marginTop: 2 }}>+</button>
          </div>
        </div>);
      })}
    </div>}

    {/* List View */}
    {view === "list" && <div>
      <div style={{ display: "flex", gap: 6, marginBottom: 12, flexWrap: "wrap" }}>
        <button onClick={() => setFilterStage("")} style={{ ...S.tagBtn, color: !filterStage ? "#c9a227" : "#666", borderColor: !filterStage ? "#c9a227" : "#333" }}>All</button>
        {PIPELINE.map(s => <button key={s.key} onClick={() => setFilterStage(s.key)} style={{ ...S.tagBtn, color: filterStage === s.key ? s.color : "#666", borderColor: filterStage === s.key ? s.color : "#333" }}>{s.icon} {s.label}</button>)}
      </div>
      {filtered.length === 0 ? <EmptyState icon="📅" text="No gigs yet" /> : <div style={S.grid}>{filtered.map(g => {
        const stage = PIPELINE.find(p => p.key === (g.stage || "inquiry")) || PIPELINE[0];
        return (<div key={g.id} style={S.card} onClick={() => openEdit(g)}>
          <div style={{ display: "flex", justifyContent: "space-between" }}><div><div style={S.cardTitle}>{g.client}</div><div style={S.cardSub}>{g.date && new Date(g.date + "T12:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}{g.venue && ` · ${g.venue.split(",")[0]}`}</div></div><button onClick={e => { e.stopPropagation(); rm(g.id); }} style={S.delBtn}>✕</button></div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 4 }}><Badge label={stage.label} color={stage.color} />{g.venueType && <Badge label={g.venueType} />}{g.venueCity && <Badge label={g.venueCity} color="#6b8afd" />}</div>
          <div style={{ display: "flex", gap: 12, alignItems: "baseline", marginTop: 4 }}>{g.fee && <div style={{ color: "#c9a227", fontWeight: 600, fontSize: 18 }}>${(+g.fee).toLocaleString()}</div>}{gigExp(g) > 0 && <div style={{ color: "#ff6b6b", fontSize: 12 }}>-${gigExp(g).toFixed(0)}</div>}</div>
          {(g.contactName || g.contactCompany) && <div style={{ fontSize: 11, color: "#666", marginTop: 2 }}>👤 {g.contactName}{g.contactPosition ? ` · ${g.contactPosition}` : ""}{g.contactCompany ? ` @ ${g.contactCompany}` : ""}</div>}
          {(g.followups || []).filter(f => !f.done).length > 0 && <div style={{ fontSize: 11, color: "#ffa94d", marginTop: 2 }}>⏰ {(g.followups || []).filter(f => !f.done).length} pending task{(g.followups || []).filter(f => !f.done).length > 1 ? "s" : ""}</div>}
          <Stars value={g.rating || 0} />
        </div>);
      })}</div>}
    </div>}

    {/* Calendar View */}
    {view === "calendar" && <CalendarView gigs={filtered} />}

    {/* Gig Modal */}
    <Modal open={modal} onClose={() => setModal(false)} title={editing ? "Edit Gig" : "New Gig"} wide>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <Field label="Client / Event"><Input value={form.client || ""} onChange={e => setForm({ ...form, client: e.target.value })} placeholder="e.g. Google, Sarah's Wedding" /></Field>
        <Field label="Pipeline Stage">
          <select value={form.stage || "inquiry"} onChange={e => setForm({ ...form, stage: e.target.value })} style={S.input}>
            {PIPELINE.map(s => <option key={s.key} value={s.key}>{s.icon} {s.label}</option>)}
          </select>
        </Field>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <Field label="Date"><Input type="date" value={form.date || ""} onChange={e => setForm({ ...form, date: e.target.value })} /></Field>
        <Field label="Venue Type"><Select options={VENUE_TYPES} placeholder="Select..." value={form.venueType || ""} onChange={e => setForm({ ...form, venueType: e.target.value })} /></Field>
      </div>

      <Divider label="✦ Venue" />
      <Field label="Location (auto-search)">
        <VenueSearch value={form.venue || ""} fullAddr={form.venueAddress || ""} onChange={v => setForm({ ...form, venue: v })} onSelect={s => setForm({ ...form, venue: s.name, venueAddress: s.full, venueLat: s.lat, venueLng: s.lng, venueCity: s.city, venueState: s.state })} />
      </Field>

      <Divider label="✦ Financials" />
      <Field label="Fee ($)"><div style={{ position: "relative" }}><span style={{ position: "absolute", left: 10, top: 9, color: "#c9a227", fontWeight: 600 }}>$</span><Input type="number" value={form.fee || ""} onChange={e => setForm({ ...form, fee: e.target.value })} placeholder="1500" style={{ paddingLeft: 24, fontSize: 16, fontWeight: 600 }} /></div></Field>
      {(form.fee || (form.expenses || []).length > 0) && (() => {
        const f = +form.fee || 0, e = (form.expenses || []).reduce((s, x) => s + (+x.amount || 0), 0), p = f - e;
        return <div style={{ display: "flex", gap: 20, padding: "8px 12px", background: "#0a0a0a", borderRadius: 8, marginBottom: 12, fontSize: 13 }}><span style={{ color: "#c9a227" }}>Fee: ${f.toLocaleString()}</span><span style={{ color: "#ff6b6b" }}>Exp: -${e.toFixed(2)}</span><span style={{ color: p >= 0 ? "#22c955" : "#ff6b6b", fontWeight: 600 }}>Profit: ${p.toLocaleString()}</span></div>;
      })()}
      <ExpenseTracker expenses={form.expenses || []} onChange={expenses => setForm({ ...form, expenses })} />
      <ContactSection form={form} setForm={setForm} />
      <FollowUps items={form.followups || []} onChange={followups => setForm({ ...form, followups })} />

      <Divider label="✦ Performance" />
      <Field label="How'd it go?"><Stars value={form.rating || 0} onChange={v => setForm({ ...form, rating: v })} /></Field>
      <Field label="Setlist"><Input value={form.setlist || ""} onChange={e => setForm({ ...form, setlist: e.target.value })} /></Field>
      <Field label="Notes"><Textarea value={form.notes || ""} onChange={e => setForm({ ...form, notes: e.target.value })} rows={3} /></Field>

      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
        <button onClick={save} style={{ ...S.saveBtn, flex: 1 }}>Save Gig</button>
        {editing && ["booked", "completed", "paid"].includes(form.stage) && <button onClick={() => { save(); setInvGig({ ...form, id: editing }); }} style={{ ...S.saveBtn, flex: "none", background: "linear-gradient(135deg, #6b8afd, #4a6de0)", width: 160 }}>Generate Invoice</button>}
      </div>
    </Modal>
    <InvoiceModal gig={invGig} open={!!invGig} onClose={() => setInvGig(null)} />
  </div>);
}

// ─── NOTES TAB ───
function NotesTab({ notes, setNotes }) {
  const [modal, setModal] = useState(false); const [editing, setEditing] = useState(null); const [search, setSearch] = useState(""); const [form, setForm] = useState({});
  const SRC = ["One Ahead", "Book", "Lecture", "Video", "Convention", "Workshop", "Podcast", "Other"];
  const openNew = () => { setForm({ title: "", source: "One Ahead", sourceDetail: "", content: "", actionable: false }); setEditing(null); setModal(true); };
  const openEdit = n => { setForm({ ...n }); setEditing(n.id); setModal(true); };
  const save = () => { if (!form.title?.trim()) return; if (editing) setNotes(p => p.map(n => n.id === editing ? { ...form, id: editing } : n)); else setNotes(p => [...p, { ...form, id: uid() }]); setModal(false); };
  const rm = id => setNotes(p => p.filter(n => n.id !== id));
  const filtered = notes.filter(n => !search || n.title.toLowerCase().includes(search.toLowerCase()) || (n.content || "").toLowerCase().includes(search.toLowerCase()));
  return (<div>
    <div style={S.tabBar}><SearchBar value={search} onChange={setSearch} placeholder="Search notes..." /><button onClick={openNew} style={S.addBtn}>+ Add Note</button></div>
    {filtered.length === 0 ? <EmptyState icon="📚" text="Save insights from articles, books, lectures" /> : <div style={S.grid}>{filtered.map(n => <div key={n.id} style={S.card} onClick={() => openEdit(n)}><div style={{ display: "flex", justifyContent: "space-between" }}><div style={S.cardTitle}>{n.title}</div><button onClick={e => { e.stopPropagation(); rm(n.id); }} style={S.delBtn}>✕</button></div><div style={{ display: "flex", gap: 6, marginBottom: 6 }}><Badge label={n.source || "One Ahead"} color={n.source === "One Ahead" ? "#c9a227" : "#6b8afd"} />{n.actionable && <Badge label="Actionable" color="#22c955" />}</div>{n.content && <div style={{ ...S.cardDetail, whiteSpace: "pre-wrap", maxHeight: 80, overflow: "hidden" }}>{n.content}</div>}</div>)}</div>}
    <Modal open={modal} onClose={() => setModal(false)} title={editing ? "Edit Note" : "New Note"}>
      <Field label="Title"><Input value={form.title || ""} onChange={e => setForm({ ...form, title: e.target.value })} /></Field>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}><Field label="Source"><Select options={SRC} value={form.source || ""} onChange={e => setForm({ ...form, source: e.target.value })} /></Field><Field label="Detail"><Input value={form.sourceDetail || ""} onChange={e => setForm({ ...form, sourceDetail: e.target.value })} /></Field></div>
      <Field label="Notes"><Textarea value={form.content || ""} onChange={e => setForm({ ...form, content: e.target.value })} rows={6} /></Field>
      <label style={{ display: "flex", gap: 8, alignItems: "center", cursor: "pointer", marginBottom: 12 }}><input type="checkbox" checked={form.actionable || false} onChange={e => setForm({ ...form, actionable: e.target.checked })} /><span style={{ color: "#ccc", fontSize: 13 }}>Actionable</span></label>
      <button onClick={save} style={S.saveBtn}>Save</button>
    </Modal>
  </div>);
}

// ─── MAIN ───
const TABS = [{ key: "gigs", label: "Gigs", icon: "📅" }, { key: "tricks", label: "Tricks", icon: "🃏" }, { key: "scripts", label: "Scripts", icon: "📝" }, { key: "setlists", label: "Setlists", icon: "📋" }, { key: "notes", label: "Notes", icon: "📚" }];

export default function MagicBrain() {
  const [tab, setTab] = useState("gigs");
  const [data, setData] = useState(() => loadData() || defaultState);
  useEffect(() => { saveData(data); }, [data]);
  const set = key => fn => setData(d => ({ ...d, [key]: typeof fn === "function" ? fn(d[key]) : fn }));
  const exportData = () => { const b = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }); const u = URL.createObjectURL(b); const a = document.createElement("a"); a.href = u; a.download = "magic-brain-backup.json"; a.click(); URL.revokeObjectURL(u); };
  const importRef = useRef();
  const importData = e => { const f = e.target.files?.[0]; if (!f) return; const r = new FileReader(); r.onload = ev => { try { setData({ ...defaultState, ...JSON.parse(ev.target.result) }); } catch {} }; r.readAsText(f); };
  const stats = Object.fromEntries(Object.keys(defaultState).map(k => [k, data[k].length]));

  return (<div style={S.root}>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet" />
    <header style={S.header}><div><h1 style={S.title}><span style={{ color: "#c9a227" }}>✦</span> Magic Brain</h1><p style={S.subtitle}>Performer CRM & Tour Manager</p></div><div style={{ display: "flex", gap: 8 }}><button onClick={exportData} style={S.utilBtn}>↓ Export</button><button onClick={() => importRef.current?.click()} style={S.utilBtn}>↑ Import</button><input ref={importRef} type="file" accept=".json" onChange={importData} style={{ display: "none" }} /></div></header>
    <nav style={S.nav}>{TABS.map(t => <button key={t.key} onClick={() => setTab(t.key)} style={{ ...S.navBtn, color: tab === t.key ? "#c9a227" : "#666", borderBottom: tab === t.key ? "2px solid #c9a227" : "2px solid transparent" }}><span style={{ fontSize: 18 }}>{t.icon}</span><span>{t.label}</span>{stats[t.key] > 0 && <span style={S.navCount}>{stats[t.key]}</span>}</button>)}</nav>
    <main style={{ minHeight: 400 }}>
      {tab === "gigs" && <GigsTab gigs={data.gigs} setGigs={set("gigs")} />}
      {tab === "tricks" && <TricksTab tricks={data.tricks} setTricks={set("tricks")} />}
      {tab === "scripts" && <ScriptsTab scripts={data.scripts} setScripts={set("scripts")} />}
      {tab === "setlists" && <SetlistsTab setlists={data.setlists} setSetlists={set("setlists")} />}
      {tab === "notes" && <NotesTab notes={data.notes} setNotes={set("notes")} />}
    </main>
  </div>);
}

// ─── STYLES ───
const S = {
  root: { fontFamily: "'DM Sans', sans-serif", background: "#0d0d0d", color: "#e0e0e0", minHeight: "100vh", maxWidth: 1100, margin: "0 auto", padding: "0 16px 40px" },
  header: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "24px 0 12px", borderBottom: "1px solid #1a1a1a" },
  title: { fontFamily: "'Playfair Display', serif", fontSize: 26, fontWeight: 700, margin: 0 },
  subtitle: { fontSize: 12, color: "#666", margin: "2px 0 0" },
  utilBtn: { background: "#1a1a1a", border: "1px solid #2a2a2a", color: "#888", padding: "6px 14px", borderRadius: 6, fontSize: 12, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" },
  nav: { display: "flex", gap: 0, borderBottom: "1px solid #1a1a1a", marginBottom: 20, overflowX: "auto" },
  navBtn: { background: "none", border: "none", padding: "14px 16px 12px", cursor: "pointer", display: "flex", alignItems: "center", gap: 6, fontSize: 13, fontWeight: 500, fontFamily: "'DM Sans', sans-serif", transition: "all .15s", whiteSpace: "nowrap" },
  navCount: { background: "#1a1a1a", color: "#888", fontSize: 11, padding: "1px 7px", borderRadius: 10 },
  tabBar: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, marginBottom: 16, flexWrap: "wrap" },
  searchWrap: { position: "relative", minWidth: 160, maxWidth: 260 },
  searchIcon: { position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)", color: "#555", fontSize: 16 },
  searchInput: { width: "100%", background: "#111", border: "1px solid #222", borderRadius: 8, padding: "8px 30px 8px 32px", color: "#ccc", fontSize: 13, outline: "none", fontFamily: "'DM Sans', sans-serif", boxSizing: "border-box" },
  searchClear: { position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", color: "#555", cursor: "pointer", fontSize: 14 },
  addBtn: { background: "linear-gradient(135deg, #c9a227, #a07d1a)", border: "none", color: "#0d0d0d", padding: "8px 18px", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans', sans-serif", whiteSpace: "nowrap" },
  grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 12 },
  card: { background: "#111", border: "1px solid #1e1e1e", borderRadius: 10, padding: 16, cursor: "pointer", transition: "border-color .15s" },
  cardTitle: { fontFamily: "'Playfair Display', serif", fontSize: 16, fontWeight: 600, marginBottom: 4, color: "#eee" },
  cardSub: { fontSize: 12, color: "#777", marginBottom: 6 },
  cardDetail: { fontSize: 12, color: "#888", marginTop: 4 },
  delBtn: { background: "none", border: "none", color: "#444", cursor: "pointer", fontSize: 16, padding: "0 4px", position: "relative", top: -2 },
  badge: { display: "inline-flex", alignItems: "center", gap: 4, padding: "2px 10px", borderRadius: 12, fontSize: 11, fontWeight: 500 },
  tagBtn: { background: "#1a1a1a", border: "1px solid #333", color: "#888", padding: "4px 12px", borderRadius: 6, fontSize: 12, cursor: "pointer", fontFamily: "'DM Sans', sans-serif" },
  arrowBtn: { background: "#1a1a1a", border: "1px solid #333", color: "#888", width: 22, height: 18, borderRadius: 4, cursor: "pointer", fontSize: 10, display: "flex", alignItems: "center", justifyContent: "center", padding: 0 },
  overlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,.75)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 16 },
  modal: { background: "#141414", border: "1px solid #2a2a2a", borderRadius: 14, width: "100%", maxWidth: 620, maxHeight: "90vh", display: "flex", flexDirection: "column" },
  modalHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 24px 12px", borderBottom: "1px solid #1e1e1e" },
  modalTitle: { fontFamily: "'Playfair Display', serif", fontSize: 20, fontWeight: 600, margin: 0, color: "#eee" },
  closeBtn: { background: "none", border: "none", color: "#666", fontSize: 18, cursor: "pointer" },
  modalBody: { padding: "16px 24px 24px", overflowY: "auto" },
  field: { display: "block", marginBottom: 12 },
  fieldLabel: { display: "block", fontSize: 12, fontWeight: 500, color: "#888", marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.5px" },
  input: { width: "100%", background: "#0d0d0d", border: "1px solid #2a2a2a", borderRadius: 6, padding: "8px 12px", color: "#ddd", fontSize: 13, outline: "none", fontFamily: "'DM Sans', sans-serif", boxSizing: "border-box" },
  textarea: { width: "100%", background: "#0d0d0d", border: "1px solid #2a2a2a", borderRadius: 6, padding: "8px 12px", color: "#ddd", fontSize: 13, outline: "none", fontFamily: "'DM Sans', sans-serif", resize: "vertical", boxSizing: "border-box" },
  saveBtn: { width: "100%", background: "linear-gradient(135deg, #c9a227, #a07d1a)", border: "none", color: "#0d0d0d", padding: "12px", borderRadius: 8, fontSize: 14, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans', sans-serif", marginTop: 8 },
  dropdown: { position: "absolute", top: "100%", left: 0, right: 0, background: "#1a1a1a", border: "1px solid #333", borderRadius: 8, marginTop: 4, zIndex: 100, maxHeight: 200, overflowY: "auto" },
  dropItem: { padding: "10px 12px", cursor: "pointer", borderBottom: "1px solid #222" },
  statCard: { background: "#111", border: "1px solid #1e1e1e", borderRadius: 10, padding: "12px 14px", textAlign: "center" },
  statLabel: { fontSize: 10, color: "#666", textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 4 },
  statVal: { fontSize: 18, fontWeight: 700, fontFamily: "'Playfair Display', serif" },
  calCell: { minHeight: 70, background: "#111", borderRadius: 6, padding: 4, border: "1px solid #1a1a1a" },
};
