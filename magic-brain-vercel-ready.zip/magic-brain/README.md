# ✦ Magic Brain — Performer CRM & Tour Manager

Built for Anna DeGuzman / UP MY SLEEVES LLC.

## Features
- **Pipeline View** — Kanban: Inquiry → Negotiating → Booked → Completed → Paid
- **Calendar View** — Monthly calendar color-coded by stage
- **Invoice Generator** — Auto-generates printable invoices
- **Contact Enrichment** — AI auto-fills name/company/LinkedIn from email
- **Venue Geo-Search** — Address autocomplete via OpenStreetMap
- **Expense Tracking** — Per-gig expenses with reimbursement tracking
- **Financial Dashboard** — Pipeline value, revenue, expenses, net profit
- **Tricks Database** — Log effects with category, difficulty, reaction rating
- **Scripts & Patter** — Store hooks, full scripts, callbacks
- **Setlists** — Build and reorder show sets
- **Research Notes** — Save insights from books, lectures, One Ahead

---

## 🚀 Deploy to Vercel

### Step 1 — Push to GitHub
```bash
cd magic-brain
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/YOUR_USERNAME/magic-brain.git
git push -u origin main
```

### Step 2 — Deploy on Vercel
1. Go to [vercel.com/new](https://vercel.com/new)
2. Import your GitHub repo
3. Add Environment Variable before deploying:
   - **Key:** `VITE_ANTHROPIC_API_KEY`
   - **Value:** your key from [console.anthropic.com](https://console.anthropic.com)
4. Click **Deploy** ✓

> The API key powers Contact Enrichment. Without it, everything else still works.

---

## 💻 Local Dev

```bash
cp .env.example .env.local   # then paste your API key inside
npm install
npm run dev                   # http://localhost:5173
```

---

## 💾 Data
Stored in browser localStorage. Use Export/Import buttons to back up your data.
