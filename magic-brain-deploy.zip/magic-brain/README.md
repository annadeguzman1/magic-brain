# ✦ Magic Brain — Performer CRM & Tour Manager

A full-featured CRM and tour management app for working magicians and performers. Built for Anna DeGuzman / UP MY SLEEVES LLC.

## Features
- **Pipeline View** — Kanban board: Inquiry → Negotiating → Booked → Completed → Paid
- **Calendar View** — Monthly calendar color-coded by pipeline stage
- **Invoice Generator** — Auto-generates printable invoices with fee + reimbursable expenses
- **Contact Enrichment** — Type an email, auto-fills name/company/LinkedIn/phone
- **Venue Geo-Search** — Auto-complete venue addresses with OpenStreetMap
- **Expense & Receipt Tracking** — Per-gig expenses with reimbursement tracking
- **Follow-up Tasks** — Send Contract, Invoice, Thank You, Request Review
- **Financial Dashboard** — Pipeline value, revenue, expenses, net profit
- **Tricks Database** — Log every effect with category, difficulty, reaction rating
- **Scripts & Patter** — Store hooks, full scripts, and callbacks
- **Setlists** — Build and reorder show sets
- **Research Notes** — Save insights from One Ahead, books, lectures

## Deploy to Vercel

### Option A: GitHub + Vercel (recommended)
1. Push this folder to a new GitHub repo
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import the GitHub repo
4. Vercel auto-detects Vite — click Deploy
5. Done! Your app is live at `your-project.vercel.app`

### Option B: Vercel CLI
```bash
npm install -g vercel
cd magic-brain
npm install
vercel
```

## Local Development
```bash
npm install
npm run dev
```
Opens at `http://localhost:5173`

## Data Storage
All data is stored in your browser's localStorage. Use the Export/Import buttons to back up your data as JSON.
